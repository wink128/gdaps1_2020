﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Cie Thompson
// 1/24/19
// Mad Libs (input and parsing PE)

// This starter file is for use with the MadLibs exercise in week 3
// Why are you starting with a starter file?
// Because sometimes you will start with a starter file for PE's or HW's
//  and we want to be sure you know how to code in someone else's starter file. 
// Feel free to delete this paragraph after you read it. 

namespace MadLib_Starter_2019
{
    class Program
    {
        static void Main(string[] args)
        {
            // --------------------------------------------------
            // Set up all necessary variables
            // Declare them only, don't initialize
            // For example:
            //   string famousPerson;
            //   string numberString;
            //   int parsedNumber;
            // --------------------------------------------------

            string name;
            string location;
            string adj1;
            string noun1;
            string adj2;
            string noun2;
            int num1;
            int num2;
            string clothing;

            // --------------------------------------------------
            // Introductory code
            // Get the user's name and welcome them to the game
            // --------------------------------------------------

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("What's your name? ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            name = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("Hi ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write(name);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("! Welcome to Mad Libs!");
            Console.WriteLine();

            // --------------------------------------------------
            // Get user input for all needed MadLib words
            // And assign each value into each corresponding variable
            // For example:
            //     famousPerson = Console.ReadLine();
            //
            //     numberString = Console.ReadLine();
            //     parsedNumber = int.Parse(numberString);
            // --------------------------------------------------

            Console.Write("Enter a geographic location: ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            location = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;

            Console.Write("Enter an adjective: ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            adj1 = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;

            Console.Write("Enter a plural noun: ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            noun1 = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;

            Console.Write("Enter another adjective: ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            adj2 = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;

            Console.Write("Enter another plural noun: ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            noun2 = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;

            Console.Write("Enter a number between 1 and 100: ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            num1 = (int.Parse(Console.ReadLine()) * 2);
            Console.ForegroundColor = ConsoleColor.Blue;

            Console.Write("Enter another number between 1 and 100: ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            num2 = (int.Parse(Console.ReadLine()) / 50);
            Console.ForegroundColor = ConsoleColor.Blue;

            Console.Write("Enter an article of clothing: ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            clothing = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine();

            // --------------------------------------------------
            // Print story to console in a different text color than white
            // --------------------------------------------------

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("Here is tomorrow's weather report for ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write(location + "\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("and vicinity. Early tomorrow, a ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write(adj1);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write(" front will\ncollide with a mass of hot ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write(noun1);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write(" moving from the\nnorth. This means we can expect ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write(adj2);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write(" winds and\noccasional ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write(noun2);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write(" by late afternoon. Wind velocity will\nbe ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write(num1);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write(" miles an hour, so the high temperature should\n" +
                "be around ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write(num2);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write(" degree(s). So, if you're going out, you had\n" +
                "better plan on wearing your ");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write(clothing);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(".");

            // Keep window open
            Console.ReadLine();
        }
    }
}
