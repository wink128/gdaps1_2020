﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hello_World
{
    // Cie Thompson
    // Class: Program
    // The main class for this program containing my main method
    // Restrictions: none

    class Program
    {
        static void Main(string[] args)
        {
            // Print hello world to the console
            Console.WriteLine("Hello World!");

            /* My name is Cie Thompson
             * It seems important to add my name here
             * so I did.
             */
            
            Console.WriteLine("Cie Thompson");

            /* For this, do I really need the ReadLine here?
             * When running without debugging it already has the
             * "Press any key to continue..." when it reaches the end
             * so it seems kinda redundant to me but idk.
             */

            Console.ReadLine();
        }
    }
}
